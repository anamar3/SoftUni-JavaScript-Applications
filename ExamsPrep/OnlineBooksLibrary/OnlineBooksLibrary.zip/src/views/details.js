import {html, nothing} from '../../node_modules/lit-html/lit-html.js';
import { deleteBook, getById } from '../api/books.js';
import { getUserData } from '../api/utils.js';

const detailsTemplate = (book,onDelete) => html`
  <section id="details-page" class="details">
            <div class="book-information">
                <h3>${book.title}</h3>
                <p class="type">Type: ${book.type}</p>
                <p class="img"><img src=${book.imageUrl}></p>
              
            </div>
                <div class="actions">
                    <!-- Edit/Delete buttons ( Only for creator of this book )  -->
                    ${book.isOwner ? html `<a class="button" href='/edit/${book._id}' >Edit</a>
                    <a @click=${onDelete} class="button" href="javascript:void(0)">Delete</a>`: nothing}
                 
                    <!-- ${book.isOwner==null && getUserData().token ? html`<a class="button" href="#">Like</a>`: nothing} -->

                    <div class="likes">
                        <img class="hearts" src="/images/heart.png">
                        <span id="total-likes">Likes: 0</span>
                    </div>
               </div>
                    <!-- Bonus -->
                    <!-- Like button ( Only for logged-in users, which is not creators of the current book ) -->
                    <!--  -->

                    <!-- ( for Guests and Users )  -->
                   
                    <!-- Bonus -->
                
                    <div class="book-description">
                <h3>Description:</h3>
                <p>${book.description}</p>
                </div>

        
        </section>
`

export async function detailsView(ctx){
    const book = await getById(ctx.params.id);
    if(ctx.user !=null){
  if(book._ownerId == ctx.user.id){
    book.isOwner = true;
  }}else{
    book.isOwner = false;
  }
  

  ctx.render(detailsTemplate(book,onDelete));

  async function onDelete(e){
    e.preventDefault();
    const choice = confirm('Are you sure you want to delete this game?');
if(choice){
    await deleteBook(ctx.params.id);
    ctx.page.redirect('/');
}
}
}

